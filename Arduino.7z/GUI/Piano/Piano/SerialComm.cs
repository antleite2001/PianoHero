﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.ComponentModel.Design;
using System.Management;

namespace Piano
{
  internal class MySerialPort
  {





    string portList = "";

    public RxByteReceived rxByteReceived = new RxByteReceived();



    public System.IO.Ports.SerialPort sp = null;

    Excel._Worksheet worksheet;

    Form1 main;



    //string CurrentSelectedSerialPort;





    private bool ThisSerialPort_DataReceived_Assigned = false;

    public bool Assign_ThisSerialPort_DataReceived
    {
      set
      {
        if ((value == true) && (ThisSerialPort_DataReceived_Assigned == false))
        {
          sp.DataReceived += ThisSerialPort_DataReceived;
          ThisSerialPort_DataReceived_Assigned = true;

        }
        else if ((value == false) && (ThisSerialPort_DataReceived_Assigned == true))
        {
          sp.DataReceived -= ThisSerialPort_DataReceived;
          ThisSerialPort_DataReceived_Assigned = false;
        }
      }
    }



    /* Initializes and Open Serial comm*/
    public MySerialPort(Excel._Worksheet worksheet, Form1 main)
    {
      this.worksheet = worksheet;

      this.main = main;



      /* create a new serial port*/
      sp = new System.IO.Ports.SerialPort();

      sp.ReadTimeout = 1000;

      sp.Parity = Parity.None;

      sp.StopBits = StopBits.One;

      sp.DataBits = 8;

      sp.Handshake = Handshake.None;

      sp.ReceivedBytesThreshold = 1;

      sp.BaudRate = 115200;

      RescanSerialPort();
    }


    public void RescanSerialPort()
    {

      main.tsSerialPortStatus.Text = "";

      worksheet.Select();

      GetSerialPortInfo();

      if (!string.IsNullOrEmpty(portList))
      {
        sp.PortName = portList;

        if (sp.IsOpen)
        {
          Assign_ThisSerialPort_DataReceived = false;

          sp.Close();/* disconnect SerialPort */



        }

        try
        {
          main.tsSerialPortStatus.Text = "Trying to open " + sp.PortName;

          sp.Open(); /* try to connect with device */

        }
        catch
        {

        }


      }





      /* If open, subscribe events */
      if (sp.IsOpen)
      {


        main.tsSerialPortStatus.Text = "Connected: " + sp.PortName;

        Assign_ThisSerialPort_DataReceived = true;
      }
      else
      {
        main.tsSerialPortStatus.Text = "Cannot open " + sp.PortName;
        MessageBox.Show("Cannot open " + sp.PortName);
      }

    }


    void GetSerialPortInfo()
    {
      portList = "";

      using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT Caption FROM Win32_PnPEntity WHERE Caption like '%Arduino Uno%'"))
      {

        var p = searcher.Get().Cast<ManagementBaseObject>().ToList().Select(p1 => p1["Caption"].ToString());

        foreach (string s in p.ToList())
        {
          if (s.ToUpper().Contains("ARDUINO UNO"))
          {
            portList=s.Substring(13, 4);//COMx
            break;
          }

        }


      }
    }

    private void ThisSerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
      try
      {
        while (sp.BytesToRead > 0)
        {
          rxByteReceived.RxByteRaiseEvent((byte)sp.ReadByte());
        }
      }
      catch { }
    }


    public void SendByte(byte[] b, int count)
    {
      try
      {
        sp.Write(b, 0, count);
      }
      catch (Exception)
      {


      }
    }

  }

  #region Notifications
  public class RxByteReceived
  {
    //1-delegate (search for OnUART1ByteReceived in main)
    public event EventHandler<EventArgsRxByte> Subscribe; //Points to nothing until a subscription is done (in main)

    //2-Raise
    public void RxByteRaiseEvent(byte RxByte)
    {
      /* notify subscribers a new byte has arrived */
      Subscribe?.Invoke(this, new EventArgsRxByte(RxByte));
    }


  }
  public class EventArgsRxByte : EventArgs
  {
    public byte RxByte { get; private set; }


    public EventArgsRxByte(byte RxByte)
    {
      this.RxByte = RxByte;

    }


  }

  #endregion Notifications











}
