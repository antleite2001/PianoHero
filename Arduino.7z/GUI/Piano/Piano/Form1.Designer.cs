﻿
namespace Piano
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tpMusic = new System.Windows.Forms.TabPage();
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.tsSerialPortStatus = new System.Windows.Forms.ToolStripStatusLabel();
      this.tsSerialPortMessage = new System.Windows.Forms.ToolStripStatusLabel();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.nupShiftOctave = new System.Windows.Forms.NumericUpDown();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.nudEndRow = new System.Windows.Forms.NumericUpDown();
      this.label5 = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.nudStartRow = new System.Windows.Forms.NumericUpDown();
      this.label4 = new System.Windows.Forms.Label();
      this.btmInitMatriz = new System.Windows.Forms.Button();
      this.cbShowExcelRowNumber = new System.Windows.Forms.CheckBox();
      this.label6 = new System.Windows.Forms.Label();
      this.rtb1 = new System.Windows.Forms.RichTextBox();
      this.gbKeys = new System.Windows.Forms.GroupBox();
      this.cbAll = new System.Windows.Forms.CheckBox();
      this.cb_7 = new System.Windows.Forms.CheckBox();
      this.cb_6 = new System.Windows.Forms.CheckBox();
      this.cb_5 = new System.Windows.Forms.CheckBox();
      this.cb_4 = new System.Windows.Forms.CheckBox();
      this.cb_3 = new System.Windows.Forms.CheckBox();
      this.cb_2 = new System.Windows.Forms.CheckBox();
      this.cb_1 = new System.Windows.Forms.CheckBox();
      this.cb_B = new System.Windows.Forms.CheckBox();
      this.cb_A = new System.Windows.Forms.CheckBox();
      this.cb_G = new System.Windows.Forms.CheckBox();
      this.cb_F = new System.Windows.Forms.CheckBox();
      this.cb_E = new System.Windows.Forms.CheckBox();
      this.cb_D = new System.Windows.Forms.CheckBox();
      this.cb_C = new System.Windows.Forms.CheckBox();
      this.nudSecondsUntilStart = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.gbBrightness = new System.Windows.Forms.GroupBox();
      this.rbBrightness15 = new System.Windows.Forms.RadioButton();
      this.rbBrightness14 = new System.Windows.Forms.RadioButton();
      this.rbBrightness13 = new System.Windows.Forms.RadioButton();
      this.rbBrightness12 = new System.Windows.Forms.RadioButton();
      this.rbBrightness11 = new System.Windows.Forms.RadioButton();
      this.rbBrightness10 = new System.Windows.Forms.RadioButton();
      this.rbBrightness09 = new System.Windows.Forms.RadioButton();
      this.rbBrightness08 = new System.Windows.Forms.RadioButton();
      this.rbBrightness07 = new System.Windows.Forms.RadioButton();
      this.rbBrightness06 = new System.Windows.Forms.RadioButton();
      this.rbBrightness05 = new System.Windows.Forms.RadioButton();
      this.rbBrightness04 = new System.Windows.Forms.RadioButton();
      this.rbBrightness03 = new System.Windows.Forms.RadioButton();
      this.rbBrightness02 = new System.Windows.Forms.RadioButton();
      this.rbBrightness01 = new System.Windows.Forms.RadioButton();
      this.rbBrightness00 = new System.Windows.Forms.RadioButton();
      this.dgvMusics = new System.Windows.Forms.DataGridView();
      this.Music = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Comment = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.Notes = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.TabName = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.btnStop = new System.Windows.Forms.Button();
      this.btnRestart = new System.Windows.Forms.Button();
      this.nudaTimerMultiplier = new System.Windows.Forms.NumericUpDown();
      this.lblMultiplier = new System.Windows.Forms.Label();
      this.button2 = new System.Windows.Forms.Button();
      this.tabControl1.SuspendLayout();
      this.tpMusic.SuspendLayout();
      this.statusStrip1.SuspendLayout();
      this.groupBox3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nupShiftOctave)).BeginInit();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudEndRow)).BeginInit();
      this.groupBox1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudStartRow)).BeginInit();
      this.gbKeys.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudSecondsUntilStart)).BeginInit();
      this.gbBrightness.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvMusics)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudaTimerMultiplier)).BeginInit();
      this.SuspendLayout();
      // 
      // tabControl1
      // 
      this.tabControl1.Controls.Add(this.tpMusic);
      this.tabControl1.Location = new System.Drawing.Point(12, 12);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(957, 618);
      this.tabControl1.TabIndex = 0;
      // 
      // tpMusic
      // 
      this.tpMusic.Controls.Add(this.statusStrip1);
      this.tpMusic.Controls.Add(this.groupBox3);
      this.tpMusic.Controls.Add(this.groupBox2);
      this.tpMusic.Controls.Add(this.groupBox1);
      this.tpMusic.Controls.Add(this.btmInitMatriz);
      this.tpMusic.Controls.Add(this.cbShowExcelRowNumber);
      this.tpMusic.Controls.Add(this.label6);
      this.tpMusic.Controls.Add(this.rtb1);
      this.tpMusic.Controls.Add(this.gbKeys);
      this.tpMusic.Controls.Add(this.nudSecondsUntilStart);
      this.tpMusic.Controls.Add(this.label1);
      this.tpMusic.Controls.Add(this.gbBrightness);
      this.tpMusic.Controls.Add(this.dgvMusics);
      this.tpMusic.Controls.Add(this.btnStop);
      this.tpMusic.Controls.Add(this.btnRestart);
      this.tpMusic.Controls.Add(this.nudaTimerMultiplier);
      this.tpMusic.Controls.Add(this.lblMultiplier);
      this.tpMusic.Controls.Add(this.button2);
      this.tpMusic.Location = new System.Drawing.Point(4, 22);
      this.tpMusic.Name = "tpMusic";
      this.tpMusic.Padding = new System.Windows.Forms.Padding(3);
      this.tpMusic.Size = new System.Drawing.Size(949, 592);
      this.tpMusic.TabIndex = 1;
      this.tpMusic.Text = "Music";
      this.tpMusic.UseVisualStyleBackColor = true;
      // 
      // statusStrip1
      // 
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsSerialPortStatus,
            this.tsSerialPortMessage});
      this.statusStrip1.Location = new System.Drawing.Point(3, 567);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new System.Drawing.Size(943, 22);
      this.statusStrip1.TabIndex = 19;
      this.statusStrip1.Text = "statusStrip1";
      // 
      // tsSerialPortStatus
      // 
      this.tsSerialPortStatus.AutoSize = false;
      this.tsSerialPortStatus.Name = "tsSerialPortStatus";
      this.tsSerialPortStatus.Size = new System.Drawing.Size(500, 17);
      this.tsSerialPortStatus.Text = "tsSerialPortStatus";
      this.tsSerialPortStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // tsSerialPortMessage
      // 
      this.tsSerialPortMessage.Name = "tsSerialPortMessage";
      this.tsSerialPortMessage.Size = new System.Drawing.Size(112, 17);
      this.tsSerialPortMessage.Text = "tsSerialPortMessage";
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.nupShiftOctave);
      this.groupBox3.Location = new System.Drawing.Point(133, 361);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(140, 71);
      this.groupBox3.TabIndex = 51;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Shift Octaves";
      // 
      // nupShiftOctave
      // 
      this.nupShiftOctave.Location = new System.Drawing.Point(12, 19);
      this.nupShiftOctave.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
      this.nupShiftOctave.Minimum = new decimal(new int[] {
            7,
            0,
            0,
            -2147483648});
      this.nupShiftOctave.Name = "nupShiftOctave";
      this.nupShiftOctave.Size = new System.Drawing.Size(120, 20);
      this.nupShiftOctave.TabIndex = 40;
      this.nupShiftOctave.ValueChanged += new System.EventHandler(this.nupShiftOctave_ValueChanged);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.nudEndRow);
      this.groupBox2.Controls.Add(this.label5);
      this.groupBox2.Location = new System.Drawing.Point(164, 141);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(140, 71);
      this.groupBox2.TabIndex = 50;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Excel End Row";
      // 
      // nudEndRow
      // 
      this.nudEndRow.Location = new System.Drawing.Point(12, 19);
      this.nudEndRow.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
      this.nudEndRow.Name = "nudEndRow";
      this.nudEndRow.Size = new System.Drawing.Size(120, 20);
      this.nudEndRow.TabIndex = 40;
      this.nudEndRow.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
      this.nudEndRow.ValueChanged += new System.EventHandler(this.nudEndRow_ValueChanged);
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(9, 46);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(93, 13);
      this.label5.TabIndex = 45;
      this.label5.Text = "0 or 1: To the End";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.nudStartRow);
      this.groupBox1.Controls.Add(this.label4);
      this.groupBox1.Location = new System.Drawing.Point(18, 141);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(140, 71);
      this.groupBox1.TabIndex = 49;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Excel Start Row";
      // 
      // nudStartRow
      // 
      this.nudStartRow.Location = new System.Drawing.Point(6, 19);
      this.nudStartRow.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
      this.nudStartRow.Name = "nudStartRow";
      this.nudStartRow.Size = new System.Drawing.Size(120, 20);
      this.nudStartRow.TabIndex = 39;
      this.nudStartRow.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
      this.nudStartRow.ValueChanged += new System.EventHandler(this.nudStartRow_ValueChanged);
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(6, 46);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(130, 13);
      this.label4.TabIndex = 44;
      this.label4.Text = "0 or 1: From the beginning";
      // 
      // btmInitMatriz
      // 
      this.btmInitMatriz.Location = new System.Drawing.Point(266, 45);
      this.btmInitMatriz.Name = "btmInitMatriz";
      this.btmInitMatriz.Size = new System.Drawing.Size(118, 23);
      this.btmInitMatriz.TabIndex = 48;
      this.btmInitMatriz.Text = "Init Matriz";
      this.btmInitMatriz.UseVisualStyleBackColor = true;
      this.btmInitMatriz.Click += new System.EventHandler(this.btmInitMatriz_Click);
      // 
      // cbShowExcelRowNumber
      // 
      this.cbShowExcelRowNumber.AutoSize = true;
      this.cbShowExcelRowNumber.Location = new System.Drawing.Point(200, 74);
      this.cbShowExcelRowNumber.Name = "cbShowExcelRowNumber";
      this.cbShowExcelRowNumber.Size = new System.Drawing.Size(147, 17);
      this.cbShowExcelRowNumber.TabIndex = 15;
      this.cbShowExcelRowNumber.Text = "Show Excel Row Number";
      this.cbShowExcelRowNumber.UseVisualStyleBackColor = true;
      this.cbShowExcelRowNumber.CheckedChanged += new System.EventHandler(this.cbShowExcelRowNumber_CheckedChanged);
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(21, 96);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(114, 13);
      this.label6.TabIndex = 47;
      this.label6.Text = "Extend time (1=250ms)";
      // 
      // rtb1
      // 
      this.rtb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.rtb1.Location = new System.Drawing.Point(390, 392);
      this.rtb1.Name = "rtb1";
      this.rtb1.Size = new System.Drawing.Size(538, 117);
      this.rtb1.TabIndex = 46;
      this.rtb1.Text = "";
      // 
      // gbKeys
      // 
      this.gbKeys.Controls.Add(this.cbAll);
      this.gbKeys.Controls.Add(this.cb_7);
      this.gbKeys.Controls.Add(this.cb_6);
      this.gbKeys.Controls.Add(this.cb_5);
      this.gbKeys.Controls.Add(this.cb_4);
      this.gbKeys.Controls.Add(this.cb_3);
      this.gbKeys.Controls.Add(this.cb_2);
      this.gbKeys.Controls.Add(this.cb_1);
      this.gbKeys.Controls.Add(this.cb_B);
      this.gbKeys.Controls.Add(this.cb_A);
      this.gbKeys.Controls.Add(this.cb_G);
      this.gbKeys.Controls.Add(this.cb_F);
      this.gbKeys.Controls.Add(this.cb_E);
      this.gbKeys.Controls.Add(this.cb_D);
      this.gbKeys.Controls.Add(this.cb_C);
      this.gbKeys.Location = new System.Drawing.Point(18, 217);
      this.gbKeys.Name = "gbKeys";
      this.gbKeys.Size = new System.Drawing.Size(98, 216);
      this.gbKeys.TabIndex = 43;
      this.gbKeys.TabStop = false;
      this.gbKeys.Text = "Turn on Keys";
      // 
      // cbAll
      // 
      this.cbAll.AutoSize = true;
      this.cbAll.Location = new System.Drawing.Point(16, 193);
      this.cbAll.Name = "cbAll";
      this.cbAll.Size = new System.Drawing.Size(37, 17);
      this.cbAll.TabIndex = 50;
      this.cbAll.Text = "All";
      this.cbAll.UseVisualStyleBackColor = true;
      this.cbAll.CheckedChanged += new System.EventHandler(this.cbAll_CheckedChanged);
      // 
      // cb_7
      // 
      this.cb_7.AutoSize = true;
      this.cb_7.Location = new System.Drawing.Point(55, 160);
      this.cb_7.Name = "cb_7";
      this.cb_7.Size = new System.Drawing.Size(32, 17);
      this.cb_7.TabIndex = 14;
      this.cb_7.Text = "7";
      this.cb_7.UseVisualStyleBackColor = true;
      this.cb_7.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_6
      // 
      this.cb_6.AutoSize = true;
      this.cb_6.Location = new System.Drawing.Point(55, 137);
      this.cb_6.Name = "cb_6";
      this.cb_6.Size = new System.Drawing.Size(32, 17);
      this.cb_6.TabIndex = 13;
      this.cb_6.Text = "6";
      this.cb_6.UseVisualStyleBackColor = true;
      this.cb_6.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_5
      // 
      this.cb_5.AutoSize = true;
      this.cb_5.Location = new System.Drawing.Point(55, 114);
      this.cb_5.Name = "cb_5";
      this.cb_5.Size = new System.Drawing.Size(32, 17);
      this.cb_5.TabIndex = 12;
      this.cb_5.Text = "5";
      this.cb_5.UseVisualStyleBackColor = true;
      this.cb_5.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_4
      // 
      this.cb_4.AutoSize = true;
      this.cb_4.Location = new System.Drawing.Point(55, 91);
      this.cb_4.Name = "cb_4";
      this.cb_4.Size = new System.Drawing.Size(32, 17);
      this.cb_4.TabIndex = 11;
      this.cb_4.Text = "4";
      this.cb_4.UseVisualStyleBackColor = true;
      this.cb_4.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_3
      // 
      this.cb_3.AutoSize = true;
      this.cb_3.Location = new System.Drawing.Point(55, 68);
      this.cb_3.Name = "cb_3";
      this.cb_3.Size = new System.Drawing.Size(32, 17);
      this.cb_3.TabIndex = 10;
      this.cb_3.Text = "3";
      this.cb_3.UseVisualStyleBackColor = true;
      this.cb_3.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_2
      // 
      this.cb_2.AutoSize = true;
      this.cb_2.Location = new System.Drawing.Point(55, 45);
      this.cb_2.Name = "cb_2";
      this.cb_2.Size = new System.Drawing.Size(32, 17);
      this.cb_2.TabIndex = 9;
      this.cb_2.Text = "2";
      this.cb_2.UseVisualStyleBackColor = true;
      this.cb_2.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_1
      // 
      this.cb_1.AutoSize = true;
      this.cb_1.Location = new System.Drawing.Point(55, 22);
      this.cb_1.Name = "cb_1";
      this.cb_1.Size = new System.Drawing.Size(32, 17);
      this.cb_1.TabIndex = 8;
      this.cb_1.Text = "1";
      this.cb_1.UseVisualStyleBackColor = true;
      this.cb_1.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_B
      // 
      this.cb_B.AutoSize = true;
      this.cb_B.Location = new System.Drawing.Point(16, 160);
      this.cb_B.Name = "cb_B";
      this.cb_B.Size = new System.Drawing.Size(33, 17);
      this.cb_B.TabIndex = 6;
      this.cb_B.Text = "B";
      this.cb_B.UseVisualStyleBackColor = true;
      this.cb_B.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_A
      // 
      this.cb_A.AutoSize = true;
      this.cb_A.Location = new System.Drawing.Point(16, 137);
      this.cb_A.Name = "cb_A";
      this.cb_A.Size = new System.Drawing.Size(33, 17);
      this.cb_A.TabIndex = 5;
      this.cb_A.Text = "A";
      this.cb_A.UseVisualStyleBackColor = true;
      this.cb_A.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_G
      // 
      this.cb_G.AutoSize = true;
      this.cb_G.Location = new System.Drawing.Point(16, 114);
      this.cb_G.Name = "cb_G";
      this.cb_G.Size = new System.Drawing.Size(34, 17);
      this.cb_G.TabIndex = 4;
      this.cb_G.Text = "G";
      this.cb_G.UseVisualStyleBackColor = true;
      this.cb_G.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_F
      // 
      this.cb_F.AutoSize = true;
      this.cb_F.Location = new System.Drawing.Point(16, 91);
      this.cb_F.Name = "cb_F";
      this.cb_F.Size = new System.Drawing.Size(32, 17);
      this.cb_F.TabIndex = 3;
      this.cb_F.Text = "F";
      this.cb_F.UseVisualStyleBackColor = true;
      this.cb_F.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_E
      // 
      this.cb_E.AutoSize = true;
      this.cb_E.Location = new System.Drawing.Point(16, 68);
      this.cb_E.Name = "cb_E";
      this.cb_E.Size = new System.Drawing.Size(33, 17);
      this.cb_E.TabIndex = 2;
      this.cb_E.Text = "E";
      this.cb_E.UseVisualStyleBackColor = true;
      this.cb_E.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_D
      // 
      this.cb_D.AutoSize = true;
      this.cb_D.Location = new System.Drawing.Point(16, 45);
      this.cb_D.Name = "cb_D";
      this.cb_D.Size = new System.Drawing.Size(34, 17);
      this.cb_D.TabIndex = 1;
      this.cb_D.Text = "D";
      this.cb_D.UseVisualStyleBackColor = true;
      this.cb_D.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // cb_C
      // 
      this.cb_C.AutoSize = true;
      this.cb_C.Location = new System.Drawing.Point(16, 22);
      this.cb_C.Name = "cb_C";
      this.cb_C.Size = new System.Drawing.Size(33, 17);
      this.cb_C.TabIndex = 0;
      this.cb_C.Text = "C";
      this.cb_C.UseVisualStyleBackColor = true;
      this.cb_C.CheckedChanged += new System.EventHandler(this.cb_TesteNotes);
      // 
      // nudSecondsUntilStart
      // 
      this.nudSecondsUntilStart.Location = new System.Drawing.Point(99, 73);
      this.nudSecondsUntilStart.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
      this.nudSecondsUntilStart.Name = "nudSecondsUntilStart";
      this.nudSecondsUntilStart.Size = new System.Drawing.Size(95, 20);
      this.nudSecondsUntilStart.TabIndex = 38;
      this.nudSecondsUntilStart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudSecondsUntilStart.ValueChanged += new System.EventHandler(this.nupSecondsUntilStart_ValueChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(96, 57);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(98, 13);
      this.label1.TabIndex = 37;
      this.label1.Text = "Seconds Until Start";
      // 
      // gbBrightness
      // 
      this.gbBrightness.Controls.Add(this.rbBrightness15);
      this.gbBrightness.Controls.Add(this.rbBrightness14);
      this.gbBrightness.Controls.Add(this.rbBrightness13);
      this.gbBrightness.Controls.Add(this.rbBrightness12);
      this.gbBrightness.Controls.Add(this.rbBrightness11);
      this.gbBrightness.Controls.Add(this.rbBrightness10);
      this.gbBrightness.Controls.Add(this.rbBrightness09);
      this.gbBrightness.Controls.Add(this.rbBrightness08);
      this.gbBrightness.Controls.Add(this.rbBrightness07);
      this.gbBrightness.Controls.Add(this.rbBrightness06);
      this.gbBrightness.Controls.Add(this.rbBrightness05);
      this.gbBrightness.Controls.Add(this.rbBrightness04);
      this.gbBrightness.Controls.Add(this.rbBrightness03);
      this.gbBrightness.Controls.Add(this.rbBrightness02);
      this.gbBrightness.Controls.Add(this.rbBrightness01);
      this.gbBrightness.Controls.Add(this.rbBrightness00);
      this.gbBrightness.Location = new System.Drawing.Point(133, 226);
      this.gbBrightness.Name = "gbBrightness";
      this.gbBrightness.Size = new System.Drawing.Size(171, 129);
      this.gbBrightness.TabIndex = 36;
      this.gbBrightness.TabStop = false;
      this.gbBrightness.Text = "Brightness";
      // 
      // rbBrightness15
      // 
      this.rbBrightness15.AutoSize = true;
      this.rbBrightness15.Location = new System.Drawing.Point(117, 96);
      this.rbBrightness15.Name = "rbBrightness15";
      this.rbBrightness15.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness15.TabIndex = 15;
      this.rbBrightness15.TabStop = true;
      this.rbBrightness15.Text = "15";
      this.rbBrightness15.UseVisualStyleBackColor = true;
      this.rbBrightness15.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness14
      // 
      this.rbBrightness14.AutoSize = true;
      this.rbBrightness14.Location = new System.Drawing.Point(80, 96);
      this.rbBrightness14.Name = "rbBrightness14";
      this.rbBrightness14.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness14.TabIndex = 14;
      this.rbBrightness14.TabStop = true;
      this.rbBrightness14.Text = "14";
      this.rbBrightness14.UseVisualStyleBackColor = true;
      this.rbBrightness14.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness13
      // 
      this.rbBrightness13.AutoSize = true;
      this.rbBrightness13.Location = new System.Drawing.Point(43, 96);
      this.rbBrightness13.Name = "rbBrightness13";
      this.rbBrightness13.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness13.TabIndex = 13;
      this.rbBrightness13.TabStop = true;
      this.rbBrightness13.Text = "13";
      this.rbBrightness13.UseVisualStyleBackColor = true;
      this.rbBrightness13.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness12
      // 
      this.rbBrightness12.AutoSize = true;
      this.rbBrightness12.Location = new System.Drawing.Point(6, 96);
      this.rbBrightness12.Name = "rbBrightness12";
      this.rbBrightness12.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness12.TabIndex = 12;
      this.rbBrightness12.TabStop = true;
      this.rbBrightness12.Text = "12";
      this.rbBrightness12.UseVisualStyleBackColor = true;
      this.rbBrightness12.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness11
      // 
      this.rbBrightness11.AutoSize = true;
      this.rbBrightness11.Location = new System.Drawing.Point(117, 74);
      this.rbBrightness11.Name = "rbBrightness11";
      this.rbBrightness11.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness11.TabIndex = 11;
      this.rbBrightness11.TabStop = true;
      this.rbBrightness11.Text = "11";
      this.rbBrightness11.UseVisualStyleBackColor = true;
      this.rbBrightness11.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness10
      // 
      this.rbBrightness10.AutoSize = true;
      this.rbBrightness10.Location = new System.Drawing.Point(80, 74);
      this.rbBrightness10.Name = "rbBrightness10";
      this.rbBrightness10.Size = new System.Drawing.Size(37, 17);
      this.rbBrightness10.TabIndex = 10;
      this.rbBrightness10.TabStop = true;
      this.rbBrightness10.Text = "10";
      this.rbBrightness10.UseVisualStyleBackColor = true;
      this.rbBrightness10.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness09
      // 
      this.rbBrightness09.AutoSize = true;
      this.rbBrightness09.Location = new System.Drawing.Point(43, 74);
      this.rbBrightness09.Name = "rbBrightness09";
      this.rbBrightness09.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness09.TabIndex = 9;
      this.rbBrightness09.TabStop = true;
      this.rbBrightness09.Text = "9";
      this.rbBrightness09.UseVisualStyleBackColor = true;
      this.rbBrightness09.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness08
      // 
      this.rbBrightness08.AutoSize = true;
      this.rbBrightness08.Location = new System.Drawing.Point(6, 74);
      this.rbBrightness08.Name = "rbBrightness08";
      this.rbBrightness08.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness08.TabIndex = 8;
      this.rbBrightness08.TabStop = true;
      this.rbBrightness08.Text = "8";
      this.rbBrightness08.UseVisualStyleBackColor = true;
      this.rbBrightness08.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness07
      // 
      this.rbBrightness07.AutoSize = true;
      this.rbBrightness07.Location = new System.Drawing.Point(117, 51);
      this.rbBrightness07.Name = "rbBrightness07";
      this.rbBrightness07.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness07.TabIndex = 7;
      this.rbBrightness07.TabStop = true;
      this.rbBrightness07.Text = "7";
      this.rbBrightness07.UseVisualStyleBackColor = true;
      this.rbBrightness07.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness06
      // 
      this.rbBrightness06.AutoSize = true;
      this.rbBrightness06.Location = new System.Drawing.Point(80, 51);
      this.rbBrightness06.Name = "rbBrightness06";
      this.rbBrightness06.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness06.TabIndex = 6;
      this.rbBrightness06.TabStop = true;
      this.rbBrightness06.Text = "6";
      this.rbBrightness06.UseVisualStyleBackColor = true;
      this.rbBrightness06.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness05
      // 
      this.rbBrightness05.AutoSize = true;
      this.rbBrightness05.Location = new System.Drawing.Point(43, 51);
      this.rbBrightness05.Name = "rbBrightness05";
      this.rbBrightness05.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness05.TabIndex = 5;
      this.rbBrightness05.TabStop = true;
      this.rbBrightness05.Text = "5";
      this.rbBrightness05.UseVisualStyleBackColor = true;
      this.rbBrightness05.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness04
      // 
      this.rbBrightness04.AutoSize = true;
      this.rbBrightness04.Location = new System.Drawing.Point(6, 51);
      this.rbBrightness04.Name = "rbBrightness04";
      this.rbBrightness04.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness04.TabIndex = 4;
      this.rbBrightness04.TabStop = true;
      this.rbBrightness04.Text = "4";
      this.rbBrightness04.UseVisualStyleBackColor = true;
      this.rbBrightness04.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness03
      // 
      this.rbBrightness03.AutoSize = true;
      this.rbBrightness03.Location = new System.Drawing.Point(117, 28);
      this.rbBrightness03.Name = "rbBrightness03";
      this.rbBrightness03.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness03.TabIndex = 3;
      this.rbBrightness03.TabStop = true;
      this.rbBrightness03.Text = "3";
      this.rbBrightness03.UseVisualStyleBackColor = true;
      this.rbBrightness03.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness02
      // 
      this.rbBrightness02.AutoSize = true;
      this.rbBrightness02.Location = new System.Drawing.Point(80, 28);
      this.rbBrightness02.Name = "rbBrightness02";
      this.rbBrightness02.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness02.TabIndex = 2;
      this.rbBrightness02.TabStop = true;
      this.rbBrightness02.Text = "2";
      this.rbBrightness02.UseVisualStyleBackColor = true;
      this.rbBrightness02.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness01
      // 
      this.rbBrightness01.AutoSize = true;
      this.rbBrightness01.Location = new System.Drawing.Point(43, 28);
      this.rbBrightness01.Name = "rbBrightness01";
      this.rbBrightness01.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness01.TabIndex = 1;
      this.rbBrightness01.TabStop = true;
      this.rbBrightness01.Text = "1";
      this.rbBrightness01.UseVisualStyleBackColor = true;
      this.rbBrightness01.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // rbBrightness00
      // 
      this.rbBrightness00.AutoSize = true;
      this.rbBrightness00.Location = new System.Drawing.Point(6, 28);
      this.rbBrightness00.Name = "rbBrightness00";
      this.rbBrightness00.Size = new System.Drawing.Size(31, 17);
      this.rbBrightness00.TabIndex = 0;
      this.rbBrightness00.TabStop = true;
      this.rbBrightness00.Text = "0";
      this.rbBrightness00.UseVisualStyleBackColor = true;
      this.rbBrightness00.CheckedChanged += new System.EventHandler(this.rbBrightness_CheckedChanged);
      // 
      // dgvMusics
      // 
      this.dgvMusics.AllowUserToAddRows = false;
      this.dgvMusics.AllowUserToDeleteRows = false;
      this.dgvMusics.AllowUserToResizeColumns = false;
      this.dgvMusics.AllowUserToResizeRows = false;
      this.dgvMusics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvMusics.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Music,
            this.Comment,
            this.Notes,
            this.TabName});
      this.dgvMusics.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
      this.dgvMusics.Location = new System.Drawing.Point(390, 16);
      this.dgvMusics.MultiSelect = false;
      this.dgvMusics.Name = "dgvMusics";
      this.dgvMusics.ReadOnly = true;
      this.dgvMusics.RowHeadersVisible = false;
      this.dgvMusics.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
      this.dgvMusics.Size = new System.Drawing.Size(538, 370);
      this.dgvMusics.TabIndex = 33;
      this.dgvMusics.SelectionChanged += new System.EventHandler(this.dgvMusics_SelectionChanged);
      // 
      // Music
      // 
      this.Music.HeaderText = "Music";
      this.Music.Name = "Music";
      this.Music.ReadOnly = true;
      this.Music.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      // 
      // Comment
      // 
      this.Comment.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
      this.Comment.HeaderText = "Comment";
      this.Comment.Name = "Comment";
      this.Comment.ReadOnly = true;
      this.Comment.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      // 
      // Notes
      // 
      this.Notes.HeaderText = "Notes";
      this.Notes.Name = "Notes";
      this.Notes.ReadOnly = true;
      this.Notes.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      // 
      // TabName
      // 
      this.TabName.HeaderText = "TabName";
      this.TabName.Name = "TabName";
      this.TabName.ReadOnly = true;
      this.TabName.Resizable = System.Windows.Forms.DataGridViewTriState.False;
      // 
      // btnStop
      // 
      this.btnStop.Location = new System.Drawing.Point(266, 16);
      this.btnStop.Name = "btnStop";
      this.btnStop.Size = new System.Drawing.Size(118, 23);
      this.btnStop.TabIndex = 31;
      this.btnStop.Text = "Stop";
      this.btnStop.UseVisualStyleBackColor = true;
      this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
      // 
      // btnRestart
      // 
      this.btnRestart.Location = new System.Drawing.Point(142, 16);
      this.btnRestart.Name = "btnRestart";
      this.btnRestart.Size = new System.Drawing.Size(118, 23);
      this.btnRestart.TabIndex = 30;
      this.btnRestart.Text = "Restart";
      this.btnRestart.UseVisualStyleBackColor = true;
      this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
      // 
      // nudaTimerMultiplier
      // 
      this.nudaTimerMultiplier.Location = new System.Drawing.Point(18, 73);
      this.nudaTimerMultiplier.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
      this.nudaTimerMultiplier.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudaTimerMultiplier.Name = "nudaTimerMultiplier";
      this.nudaTimerMultiplier.Size = new System.Drawing.Size(74, 20);
      this.nudaTimerMultiplier.TabIndex = 29;
      this.nudaTimerMultiplier.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudaTimerMultiplier.ValueChanged += new System.EventHandler(this.nupMultiplier_ValueChanged);
      // 
      // lblMultiplier
      // 
      this.lblMultiplier.AutoSize = true;
      this.lblMultiplier.Location = new System.Drawing.Point(15, 57);
      this.lblMultiplier.Name = "lblMultiplier";
      this.lblMultiplier.Size = new System.Drawing.Size(62, 13);
      this.lblMultiplier.TabIndex = 28;
      this.lblMultiplier.Text = "Extend time";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(18, 16);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(118, 23);
      this.button2.TabIndex = 26;
      this.button2.Text = "Play Music";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new System.EventHandler(this.btnSendSequence_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(978, 670);
      this.Controls.Add(this.tabControl1);
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "PianoHero";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
      this.Load += new System.EventHandler(this.Form1_Load);
      this.tabControl1.ResumeLayout(false);
      this.tpMusic.ResumeLayout(false);
      this.tpMusic.PerformLayout();
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.nupShiftOctave)).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudEndRow)).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudStartRow)).EndInit();
      this.gbKeys.ResumeLayout(false);
      this.gbKeys.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudSecondsUntilStart)).EndInit();
      this.gbBrightness.ResumeLayout(false);
      this.gbBrightness.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgvMusics)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudaTimerMultiplier)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tpMusic;
    private System.Windows.Forms.StatusStrip statusStrip1;
    public System.Windows.Forms.ToolStripStatusLabel tsSerialPortStatus;
    private System.Windows.Forms.ToolStripStatusLabel tsSerialPortMessage;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Label lblMultiplier;
    private System.Windows.Forms.NumericUpDown nudaTimerMultiplier;
    private System.Windows.Forms.Button btnRestart;
    private System.Windows.Forms.Button btnStop;
    private System.Windows.Forms.DataGridView dgvMusics;
    private System.Windows.Forms.DataGridViewTextBoxColumn Music;
    private System.Windows.Forms.DataGridViewTextBoxColumn Comment;
    private System.Windows.Forms.DataGridViewTextBoxColumn Notes;
    private System.Windows.Forms.DataGridViewTextBoxColumn TabName;
    private System.Windows.Forms.GroupBox gbBrightness;
    private System.Windows.Forms.RadioButton rbBrightness15;
    private System.Windows.Forms.RadioButton rbBrightness14;
    private System.Windows.Forms.RadioButton rbBrightness13;
    private System.Windows.Forms.RadioButton rbBrightness12;
    private System.Windows.Forms.RadioButton rbBrightness11;
    private System.Windows.Forms.RadioButton rbBrightness10;
    private System.Windows.Forms.RadioButton rbBrightness09;
    private System.Windows.Forms.RadioButton rbBrightness08;
    private System.Windows.Forms.RadioButton rbBrightness07;
    private System.Windows.Forms.RadioButton rbBrightness06;
    private System.Windows.Forms.RadioButton rbBrightness05;
    private System.Windows.Forms.RadioButton rbBrightness04;
    private System.Windows.Forms.RadioButton rbBrightness03;
    private System.Windows.Forms.RadioButton rbBrightness02;
    private System.Windows.Forms.RadioButton rbBrightness01;
    private System.Windows.Forms.RadioButton rbBrightness00;
    private System.Windows.Forms.NumericUpDown nudSecondsUntilStart;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.NumericUpDown nudEndRow;
    private System.Windows.Forms.NumericUpDown nudStartRow;
    private System.Windows.Forms.GroupBox gbKeys;
    private System.Windows.Forms.CheckBox cb_B;
    private System.Windows.Forms.CheckBox cb_A;
    private System.Windows.Forms.CheckBox cb_G;
    private System.Windows.Forms.CheckBox cb_F;
    private System.Windows.Forms.CheckBox cb_E;
    private System.Windows.Forms.CheckBox cb_D;
    private System.Windows.Forms.CheckBox cb_C;
    private System.Windows.Forms.CheckBox cb_7;
    private System.Windows.Forms.CheckBox cb_6;
    private System.Windows.Forms.CheckBox cb_5;
    private System.Windows.Forms.CheckBox cb_4;
    private System.Windows.Forms.CheckBox cb_3;
    private System.Windows.Forms.CheckBox cb_2;
    private System.Windows.Forms.CheckBox cb_1;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.RichTextBox rtb1;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.CheckBox cbShowExcelRowNumber;
    private System.Windows.Forms.Button btmInitMatriz;
    private System.Windows.Forms.CheckBox cbAll;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.NumericUpDown nupShiftOctave;
  }
}

