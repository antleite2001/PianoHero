﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Core;
using System.Diagnostics;
using System.Reflection;
using Microsoft.Office.Interop.Excel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using Microsoft.CSharp.RuntimeBinder;
using static System.Windows.Forms.AxHost;
using System.Data.Common;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using System.Collections;
using System.Threading;

namespace Piano
{
  public partial class Form1 : Form
  {
     

    /* Excel vars*/
    Excel.Application excelApp = new Excel.Application();
    Excel.Workbooks workbooks;
    public Excel.Workbook workbook;
    public Excel._Worksheet worksheet;
    string ExcelPath;
    MySerialPort MySerialPort = null;

    string LastMusicSelected;    


    UInt32 CurrentExcelMusicRow = 2;
    bool send_sequence = false;
    string note;
    Int16 octave;
    UInt16 keyDuration;
    UInt16 TimerWaitResponse;

    UInt16 SecondsUntilStart;

    bool dgvMusicsReady = false;

    UInt16 d, diff;

    List<byte> TestNote = new List<byte>();

    List<byte> TestOctave = new List<byte>();



    /* Timer */
    System.Timers.Timer aTimer = new System.Timers.Timer();

    System.Timers.Timer aTimer2 = new System.Timers.Timer();



    public Form1()
    {
      InitializeComponent();

    }

    private void Form1_Load(object sender, EventArgs e)
    {



      tsSerialPortStatus.Text = "";

      tsSerialPortMessage.Text = "";

      ExcelInit();

      SerialPortInit();


      OptionsInit();



      TimerInit();

      Timer2Init();


      //Fill dgv with Musics
      foreach (Excel.Worksheet ws in workbook.Worksheets)
      {
        if (ws.Name.StartsWith("#"))
        {
          dgvMusics.Rows.Add(ws.Cells[1, 2].Value2.ToString(), ws.Cells[1, 3].Value2.ToString(), 0, ws.Name);
        }
      }

      dgvMusics.ClearSelection();

      nudaTimerMultiplier.Value = 1.0m;


      //Setup nud with Excel value
      nudSecondsUntilStart.Value = Convert.ToDecimal(workbook.Sheets["Settings"].Cells[2, 6].Value2);

      SecondsUntilStart = Convert.ToUInt16(4.0m * nudSecondsUntilStart.Value);

      LastMusicSelected = workbook.Sheets["Settings"].Cells[2, 3].Value2.ToString();

      //select LastMusicSelected in dgvMusic
      //Music sheet will be selected bu event dgvMusics_SelectionChanged
      foreach (DataGridViewRow r in dgvMusics.Rows)
      {
        if (r.Cells["TabName"].Value.ToString().Equals(LastMusicSelected))
        {
          dgvMusicsReady = true;
          r.Selected = true;
          break;
        }
      }





    }




    private void rbBrightness_CheckedChanged(object sender, EventArgs e)
    {
      string s = ((RadioButton)sender).Name;

      string brightness = s.Substring(s.Length - 2);

      //Store in Excel
      workbook.Sheets["Settings"].Cells[2, 5].Value2 = brightness;

      Debug.WriteLine("Send Brightness " + brightness);

      SerialTxArray[0] = 0xFD;
      SerialTxArray[1] = 0x01;
      SerialTxArray[2] = Convert.ToByte(brightness);
      MySerialPort.SendByte(SerialTxArray, 3);

      TimerWaitResponse = 10;

      while (TimerWaitResponse > 0)
      {
        ;
      }

    }



    private void dgvMusics_SelectionChanged(object sender, EventArgs e)
    {
      if (dgvMusicsReady && dgvMusics.SelectedRows.Count == 1)
      {
        LastMusicSelected = dgvMusics.SelectedRows[0].Cells[3].Value.ToString();

        //Update Excel Settings
        workbook.Sheets["Settings"].Cells[2, 3].Value2 = LastMusicSelected;

        //Select Sheet Music
        worksheet = workbook.Sheets[LastMusicSelected];

        worksheet.Select();

        nudStartRow.Value = Convert.ToDecimal(workbook.Sheets[LastMusicSelected].Cells[2, 7].Value2);

        nudEndRow.Value = Convert.ToDecimal(workbook.Sheets[LastMusicSelected].Cells[2, 8].Value2);

        nupShiftOctave.Value = Convert.ToDecimal(workbook.Sheets[LastMusicSelected].Cells[2, 12].Value2);

        nudaTimerMultiplier.Value = Convert.ToDecimal(workbook.Sheets[LastMusicSelected].Cells[2, 9].Value2);

        nudSecondsUntilStart.Value = Convert.ToDecimal(workbook.Sheets[LastMusicSelected].Cells[2, 10].Value2);

        cbShowExcelRowNumber.Checked = Convert.ToBoolean(workbook.Sheets[LastMusicSelected].Cells[2, 11].Value2);

        StartMusicFromBeginning();
      }
    }

    #region timer

    void TimerInit()
    {


      aTimer.Interval = 250.0;

      aTimer.Elapsed += ATimer_250ms_Elapsed;

      aTimer.Enabled = true;
    }


    void Timer2Init()
    {


      aTimer2.Interval = 5.0;

      aTimer2.Elapsed += ATimer2_5ms_Elapsed;

      aTimer2.Enabled = true;
    }


    UInt16 GetStartRow()
    {
      UInt16 r = Convert.ToUInt16(nudStartRow.Value);
      if (r == 0 || r == 1)
      {
        r = 2;
      }

      return r;

    }

    UInt16 GetEndRow()
    {
      UInt16 r = Convert.ToUInt16(nudEndRow.Value);

      if (r == 0 || r == 1)
      {
        r = GetMusicLastRow();
      }

      return r;

    }

    UInt16 GetMusicLastRow()
    {
      UInt16 r = Convert.ToUInt16(worksheet.Cells[worksheet.Rows.Count, 1].End(Excel.XlDirection.xlUp).Row);

      if (worksheet.Cells[r, 1].Value2 != -1.0D)
      {
        worksheet.Cells[r + 1, 1].Value2 = -1.0D;
      }
      return r;

    }

    private void btnSendSequence_Click(object sender, EventArgs e)
    {
      cbAll.Checked = false;

      cb_C.Checked = false;
      cb_D.Checked = false;
      cb_E.Checked = false;
      cb_F.Checked = false;
      cb_G.Checked = false;
      cb_A.Checked = false;
      cb_B.Checked = false;

      cb_1.Checked = false;
      cb_2.Checked = false;
      cb_3.Checked = false;
      cb_4.Checked = false;
      cb_5.Checked = false;
      cb_6.Checked = false;
      cb_7.Checked = false;
      gbKeys.Enabled = false;



      ClearDisplay();

      CurrentExcelMusicRow = GetStartRow();

      SecondsUntilStart = Convert.ToUInt16(4.0m * nudSecondsUntilStart.Value);

      send_sequence = true;


    }
    private void btnStop_Click(object sender, EventArgs e)
    {
      send_sequence = false;
      RemoveColumnColor();
      gbKeys.Enabled = true;
    }




    private void btnRestart_Click(object sender, EventArgs e)
    {
      RemoveColumnColor();

      SecondsUntilStart = Convert.ToUInt16(4.0m * nudSecondsUntilStart.Value);

      CurrentExcelMusicRow = GetStartRow();

      send_sequence = true;


    }


    /* to timeout resposne*/
    private void ATimer2_5ms_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
    {
      aTimer2.Enabled = false;

      if (TimerWaitResponse > 0)
      {
        TimerWaitResponse--;
      }


      aTimer2.Enabled = true;
    }


    /* to time notes duration and time between notes */
    private void ATimer_250ms_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
    {
      aTimer.Enabled = false;     


      if (send_sequence)
      {

        if (SecondsUntilStart > 1)
        {
          SecondsUntilStart--;

        }
        else
        {
          if (diff > 1)
          {
            diff--;
          }
          else
          {
            PlayNote();

            d = GetNextRow();

            while (d == 0)
            {
              PlayNote();

              d = GetNextRow();
            }

            diff = d;

          }

        }
      }


      aTimer.Enabled = true;
    }

    void RemoveColumnColor()
    {

      worksheet.Columns["A:A"].Interior.Pattern = Excel.Constants.xlNone;

    }


    void PaintCell()
    {

      RemoveColumnColor();

      Excel.Range cell = worksheet.Cells[CurrentExcelMusicRow, 1];

      cell.Select();

      cell.Interior.Color = System.Drawing.Color.Aqua;

    }


    UInt16 GetNextRow()
    {
      UInt16 retValue;

      //Check if can move to the next row
      var u = worksheet.Cells[CurrentExcelMusicRow, 1];
      var v = worksheet.Cells[CurrentExcelMusicRow + 1, 1];

      if (worksheet.Cells[CurrentExcelMusicRow + 1, 1].Value2 == -1.0D || (CurrentExcelMusicRow + 1) > GetEndRow())
      {
        StartMusicFromBeginning();

        retValue = diff;
      }
      else //new row has data. Can move to the next row
      {

        CurrentExcelMusicRow++;

        retValue = Convert.ToUInt16(Convert.ToUInt16(nudaTimerMultiplier.Value) *
          (Convert.ToUInt16(Convert.ToUInt16(v.Value2) - Convert.ToUInt16(u.Value2))));
      }
      return retValue;
    }


    void StartMusicFromBeginning()
    {


      CurrentExcelMusicRow = GetStartRow();

      diff = 1;

      SecondsUntilStart = Convert.ToUInt16(4.0m * nudSecondsUntilStart.Value);
    }


    #endregion


    void OptionsInit()
    {

      worksheet = workbook.Sheets["Settings"];

      worksheet.Select();

       

      byte brightness = Convert.ToByte(worksheet.Cells[2, 5].Value2);
      foreach (System.Windows.Forms.RadioButton control in gbBrightness.Controls)
      {
        if (control is System.Windows.Forms.RadioButton radioButton && radioButton.Name == "rbBrightness" + brightness.ToString("00"))
        {
          radioButton.Checked = true;
          break; // Exit the loop once the RadioButton is found
        }
      }

    }

    #region Excel
    void ExcelInit()
    {

      excelApp.DisplayAlerts = false;

      excelApp.Visible = true;

      excelApp.WindowState = Excel.XlWindowState.xlMaximized;

      ExcelPath = Environment.CurrentDirectory + @"\..\..\Data\Data.xlsx";

      workbooks = excelApp.Workbooks;

      workbook = workbooks.Open(ExcelPath);
    }

    #endregion



    /*Trigerred only when leaving the cell !!!*/
    private void dgvSerialCommCommands_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
    {
      Debug.Print(MethodBase.GetCurrentMethod().Name + "  " + e.ColumnIndex);

      /* use this for validating dgvCANSettings values*/

      tsSerialPortMessage.Text = "";
    }


    #region SerialPort



    void SerialPortInit()
    {


      worksheet = workbook.Sheets["Settings"];

      worksheet.Select();




      /* open serial port*/
      MySerialPort = new MySerialPort(workbook.Sheets["Settings"], this);


      //Subscribes to every new received byte
      MySerialPort.rxByteReceived.Subscribe += OnUART1ByteReceived;

    }


    public void OnUART1ByteReceived(object source, EventArgsRxByte e)
    {
      if (e.RxByte == 0)
      {
        TimerWaitResponse = 0;

      }
      Debug.WriteLine(e.RxByte);
    }



     


    #endregion Serial Port

     


    void SendExcelRowNumber(bool on)
    {
      if (on)
      {
        UInt32 n = CurrentExcelMusicRow;

        //Debug.WriteLine("Send Excel Row Number " + n.ToString());

        SerialTxArray[0] = 0xFB;

        SerialTxArray[1] = 0x06;

        //Order is reverted so that units are calculated first
        SerialTxArray[4] = (byte)(n % 10);

        n = (byte)(n / 10);

        SerialTxArray[3] = (byte)(n % 10);

        n = (byte)(n / 10);

        SerialTxArray[2] = (byte)n;

        SerialTxArray[5] = 0;

        SerialTxArray[6] = 1;

        SerialTxArray[7] = 2;

        MySerialPort.SendByte(SerialTxArray, 8);

        TimerWaitResponse = 10;

        while (TimerWaitResponse > 0)
        {
          ;
        }
      }
      else
      {
          
        //When value is 0xFF, clear displays
        SerialTxArray[0] = 0xFB;

        SerialTxArray[1] = 0x06;
         
        SerialTxArray[2] = 255;         

        SerialTxArray[3] = 255;

        SerialTxArray[4] = 255;

        SerialTxArray[5] = 0;

        SerialTxArray[6] = 1;

        SerialTxArray[7] = 2;

        MySerialPort.SendByte(SerialTxArray, 8);

        TimerWaitResponse = 10;

        while (TimerWaitResponse > 0)
        {
          ;
        }
      }
       
    }



     

    

    void UpdateRTB1(string s)
    {
      try
      {
        Invoke(new System.Action(() =>
          {
            rtb1.AppendText(DateTime.Now.ToString("s.fffff") + " " + s +
            Environment.NewLine);

            rtb1.SelectionStart = rtb1.Text.Length;
            rtb1.ScrollToCaret();
          }));
      }
      catch (Exception)
      {


      }

    }

    void PlayNote()
    {
      try
      {
        note = worksheet.Cells[CurrentExcelMusicRow, 2].Value2.ToString();

        octave = Convert.ToInt16(note.Substring(note.Length - 1));

        octave = Convert.ToInt16(octave + Convert.ToInt16(nupShiftOctave.Value));

        keyDuration = Convert.ToUInt16(25 * Convert.ToUInt16(Convert.ToUInt16(nudaTimerMultiplier.Value) * worksheet.Cells[CurrentExcelMusicRow, 3].Value2));

        if (note.Contains("#") || note.Contains("b")) //Sharp or flat
        {
          note = note.Substring(0, 2); //A# or Bb
        }
        else
        {
          note = note.Substring(0, 1); //C
        }


        UpdateRTB1(
          CurrentExcelMusicRow.ToString() + " " +
          note + " " +
          octave.ToString() + " " +
          (keyDuration * 10).ToString());

        if (cbShowExcelRowNumber.Checked)
        {
          SendExcelRowNumber(true);
        }

        PaintCell();

        UpdateDisplayOneNote(true, ConvertNoteToNumeric(note), Convert.ToByte(octave), keyDuration);

      }
      catch { }
    }

    byte ConvertNoteToNumeric(string note)
    {
      byte n=0;
      switch (note.ToUpper())
      {
        case "C":
          n = 0;
          break;

        case "C#":
        case "DB":
          n = 1;
          break;

        case "D":
          n = 2;
          break;

        case "D#":
        case "EB":
          n = 3;
          break;

        case "E":
          n = 4;
          break;

        case "F":
          n = 5;
          break;

        case "F#":
        case "GB":
          n = 6;
          break;

        case "G":
          n = 7;
          break;

        case "G#":
        case "AB":
          n = 8;
          break;

        case "A":
          n = 9;
          break;

        case "A#":
        case "BB":
          n = 10;
          break;

        case "B":
          n = 11;
          break;
      }
      return n;
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
      send_sequence = false;
      aTimer.Enabled = false;
      aTimer.Elapsed -= ATimer_250ms_Elapsed;

      aTimer2.Enabled = false;
      aTimer2.Elapsed -= ATimer2_5ms_Elapsed;


      //RemoveCellColor();
      try
      {
        // rtb.Close();
      }
      catch
      {
      }


      if (MySerialPort.sp.IsOpen)
      {
        MySerialPort.sp.Close();
      }


      try
      {
        workbook.Close(true);
        excelApp.Quit();
      }
      catch
      {
        ;
      }
    }

          
    private void nupSecondsUntilStart_ValueChanged(object sender, EventArgs e)
    {
      worksheet.Cells[2, 10].Value2 = nudSecondsUntilStart.Value;
      SecondsUntilStart = Convert.ToUInt16(nudSecondsUntilStart.Value);
    }

    private void nupMultiplier_ValueChanged(object sender, EventArgs e)
    {
      worksheet.Cells[2, 9].Value2 = nudaTimerMultiplier.Value;
    }

    private void nudStartRow_ValueChanged(object sender, EventArgs e)
    {
      workbook.Sheets[LastMusicSelected].Cells[2, 7].Value2 = nudStartRow.Value;
    }

     


    


    private void cbShowExcelRowNumber_CheckedChanged(object sender, EventArgs e)
    {
      workbook.Sheets[LastMusicSelected].Cells[2, 11].Value2 = cbShowExcelRowNumber.Checked;
      if (cbShowExcelRowNumber.Checked == false)
      {
        SendExcelRowNumber(false);
      }
    }

     


    void ClearDisplay()
    {

      SerialTxArray[0] = 0xFE; //Clear All displays      

      MySerialPort.SendByte(SerialTxArray, 1);
      
      TimerWaitResponse = 10;

      while (TimerWaitResponse > 0)
      {
        ;
      }
    }


    /*duration 25 -> 250 ms */
    void UpdateDisplayOneNote(bool on, byte note, byte octave, UInt16 duration)
    {


      SerialTxArray[0] = 0xFF;
      SerialTxArray[1] = 4;
      SerialTxArray[2] = note;
      SerialTxArray[3] = octave;
      SerialTxArray[4] = (byte)(duration >> 8);
      SerialTxArray[5] = (byte)(duration & 0xFF);
      MySerialPort.SendByte(SerialTxArray, 6);
      
      TimerWaitResponse = 10;

      while (TimerWaitResponse > 0)
      {
        ;
      }
       
    }





   



    private void btmInitMatriz_Click(object sender, EventArgs e)
    {
      SerialTxArray[0] = 0xFC; //Init Matriz     

      MySerialPort.SendByte(SerialTxArray, 1);
      
      TimerWaitResponse = 10;

      while (TimerWaitResponse > 0)
      {
        ;
      }
    }

     

    byte[] SerialTxArray = new byte[] {
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

    void ShowSelectedNotes()
    {
      if (!send_sequence)
      {
        TestNote.Clear();

      TestOctave.Clear();

      ClearDisplay();

      if (cb_C.Checked)
      {
        TestNote.Add(0); TestNote.Add(1);
      }
      if (cb_D.Checked)
      {
        TestNote.Add(2); TestNote.Add(3);
      }
      if (cb_E.Checked)
      {
        TestNote.Add(4);
      }
      if (cb_F.Checked)
      {
        TestNote.Add(5); TestNote.Add(6);
      }
      if (cb_G.Checked)
      {
        TestNote.Add(7); TestNote.Add(8);
      }
      if (cb_A.Checked)
      {
        TestNote.Add(9); TestNote.Add(10);
      }
      if (cb_B.Checked)
      {
        TestNote.Add(11);
      }

      if (cb_1.Checked)
      {
        TestOctave.Add(1);
      }
      if (cb_2.Checked)
      {
        TestOctave.Add(2);
      }
      if (cb_3.Checked)
      {
        TestOctave.Add(3);
      }
      if (cb_4.Checked)
      {
        TestOctave.Add(4);
      }
      if (cb_5.Checked)
      {
        TestOctave.Add(5);
      }
      if (cb_6.Checked)
      {
        TestOctave.Add(6);
      }
      if (cb_7.Checked)
      {
        TestOctave.Add(7);
      }

      /*Send to display */
      if (TestOctave.Count >= 1 && TestNote.Count >= 1)
      {

        foreach (byte octave in TestOctave)
        {
          foreach (byte note in TestNote)
          {

            UpdateDisplayOneNote(true, note, octave, 0xFFFF); /* forever*/

          }
        }

      }
    }
    }

    private void cb_TesteNotes(object sender, EventArgs e)
    {
      if (!cbAll.Checked)
      {
        ShowSelectedNotes();
      }

    }

    private void nupShiftOctave_ValueChanged(object sender, EventArgs e)
    {
      workbook.Sheets[LastMusicSelected].Cells[2, 12].Value2 = nupShiftOctave.Value;
    }
    private void nudEndRow_ValueChanged(object sender, EventArgs e)
    {
      workbook.Sheets[LastMusicSelected].Cells[2, 8].Value2 = GetEndRow();
    }
    private void cbAll_CheckedChanged(object sender, EventArgs e)
    {
      if (cbAll.Checked)
      {
        if (!send_sequence)
        {

          cb_C.Checked = false;
          cb_D.Checked = false;
          cb_E.Checked = false;
          cb_F.Checked = false;
          cb_G.Checked = false;
          cb_A.Checked = false;
          cb_B.Checked = false;

          cb_1.Checked = false;
          cb_2.Checked = false;
          cb_3.Checked = false;
          cb_4.Checked = false;
          cb_5.Checked = false;
          cb_6.Checked = false;
          cb_7.Checked = false;

          cb_C.Enabled = false;
          cb_D.Enabled = false;
          cb_E.Enabled = false;
          cb_F.Enabled = false;
          cb_G.Enabled = false;
          cb_A.Enabled = false;
          cb_B.Enabled = false;

          cb_1.Enabled = false;
          cb_2.Enabled = false;
          cb_3.Enabled = false;
          cb_4.Enabled = false;
          cb_5.Enabled = false;
          cb_6.Enabled = false;
          cb_7.Enabled = false;


          ClearDisplay();

          UpdateDisplayOneNote(true, 0, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 0, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 1, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 1, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 2, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 2, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 3, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 3, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 4, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 4, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 5, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 5, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 6, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 6, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 7, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 7, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 8, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 8, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 9, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 9, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 10, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 10, 7, 0xFFFF);


          UpdateDisplayOneNote(true, 11, 1, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 2, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 3, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 4, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 5, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 6, 0xFFFF);
          UpdateDisplayOneNote(true, 11, 7, 0xFFFF);


        }
      }
      else
      {
        ClearDisplay();
        cb_C.Enabled = true;
        cb_D.Enabled = true;
        cb_E.Enabled = true;
        cb_F.Enabled = true;
        cb_G.Enabled = true;
        cb_A.Enabled = true;
        cb_B.Enabled = true;

        cb_1.Enabled = true;
        cb_2.Enabled = true;
        cb_3.Enabled = true;
        cb_4.Enabled = true;
        cb_5.Enabled = true;
        cb_6.Enabled = true;
        cb_7.Enabled = true;
      }
    }




   


  }
}


